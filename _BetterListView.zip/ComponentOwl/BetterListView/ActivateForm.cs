using System.Windows.Forms;

namespace ComponentOwl.BetterListView;

/// <summary>
///   Online activation form.
/// </summary>
internal class ActivateForm : Form
{
	/// <summary>
	///   Initializes a new instance of the <see cref="T:ComponentOwl.BetterListView.ActivateForm" /> class.
	/// </summary>
	public ActivateForm()
	{
	}
}
