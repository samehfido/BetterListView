using System.Windows.Forms;

namespace ComponentOwl.BetterListView;

/// <summary>
///   Offline activation form.
/// </summary>
internal class ActivateOfflineForm : Form
{
	/// <summary>
	///   Initializes a new instance of the <see cref="T:ComponentOwl.BetterListView.ActivateOfflineForm" /> class.
	/// </summary>
	public ActivateOfflineForm()
	{
	}
}
