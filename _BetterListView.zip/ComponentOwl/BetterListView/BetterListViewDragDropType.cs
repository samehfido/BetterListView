namespace ComponentOwl.BetterListView;

internal enum BetterListViewDragDropType
{
	External = 0,
	Internal = 1,
	ItemReorder = 2,
	Undefined = 3
}
