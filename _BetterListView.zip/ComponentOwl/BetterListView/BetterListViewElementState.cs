namespace ComponentOwl.BetterListView;

internal enum BetterListViewElementState
{
	Inactive = 0,
	InactiveCoarse = 1,
	InactiveFine = 2,
	Active = 3,
	ActiveCoarse = 4,
	ActiveFine = 5,
	ActiveVisible = 6
}
