using System.Windows.Forms;

namespace ComponentOwl.BetterListView;

/// <summary>
///   Trial nag screen.
/// </summary>
internal class TrialForm : Form
{
	/// <summary>
	///   Initializes a new instance of the <see cref="T:ComponentOwl.BetterListView.TrialForm" /> class.
	/// </summary>
	public TrialForm()
	{
	}
}
