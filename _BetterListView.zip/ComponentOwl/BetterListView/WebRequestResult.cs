namespace ComponentOwl.BetterListView;

internal enum WebRequestResult
{
	Ok = 0,
	NoInternetConnection = 1,
	Other = 2
}
