using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;

[assembly: Guid("fc1d9568-bed2-49d7-bf11-0126851e36e8")]
[assembly: NeutralResourcesLanguage("en")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("3.2.2.0")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Better ListView Express")]
[assembly: AssemblyProduct("Better ListView Express")]
[assembly: AssemblyDescription("Ultimate ListView control replacement")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ComponentOwl.com")]
[assembly: AssemblyCopyright("Copyright © 2010-2012 ComponentOwl.com")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("3.2.2.0")]
